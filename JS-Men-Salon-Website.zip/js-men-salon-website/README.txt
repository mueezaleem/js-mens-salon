JS Men Salon Website
====================

Files
- index.html
- styles.css
- script.js

Business details used from the Google Maps listing
- Name: JS Men Salon
- Category: Hair salon
- Address: Shama Chowk, Stadium Rd, Sargodha 40100, Pakistan
- Phone: +92 306 8940000
- Google rating at time of build: 4.9 / 5 (49 reviews)
- Hours: 10:00 AM–12:00 AM, Monday–Sunday

Editing
1. Open index.html to change text/sections.
2. Edit the :root variables at the top of styles.css to change colors.
3. Change WHATSAPP_NUMBER in script.js if the contact number changes.
4. Service items use data-service attributes; add/copy a .service link to create another WhatsApp enquiry.
5. Gallery imagery is editorial presentation imagery from Unsplash and is not presented as photos of the actual premises.
6. The Google Map is embedded using the listing coordinates.

The website uses Google Fonts and remote Unsplash images, so an internet connection is needed for those assets.
